# R5 floor corner proposal — independent mechanical review

The selected proposal removes four small triangular corners from each existing 5 mm floor. In rear/common floor coordinates, let `u = X` and `v = Y − 72.49716 mm`. Keep both `|u + v| ≤ 224.04716 mm` and `|−u + v| ≤ 220.04716 mm`. These are 12 mm leg cuts at NE/SW and 16 mm cuts at NW/SE. Intersect the original floor with those diagonal bands so the four projecting side tabs remain intact.

This is a more conservative material change than the larger 30 mm example considered initially. The print-layout agent selected the 12/16 mm values for its saved H2D area and margin checks. This mechanical review does not independently establish printer reach or slicing success.

## Retained mounting material

An in-memory intersection of the R4 floor with the proposed bands remains one valid connected solid, with all nine closed fixing slots and all four original tabs. The closest slot profile remains 14.579799 mm from a new diagonal edge. A nominal OD10 washer has 14.238374 mm of diagonal clearance at the slot center, or at least 12.192828 mm through its nominal slot-center travel. Actual hardware selection and fastener strength are not established by these geometric checks.

## Openings and original corner lips

Each floor loses only 400 mm² of projected area / 2,000 mm³ of material, in two 72 mm² and two 128 mm² triangular openings. This is about 0.845% of the existing floor material. These openings are an intentional part of the requested case revision.

The small side retaining lips at the two outer floor corners lose their projected floor overlap. The two center-side lips retain approximately 11.394726 and 0.299406 mm² on the rear floor. The back-panel corner lips retain approximately 45.917209 and 57.888739 mm², while all four middle end-panel lips retain their original overlap. The front floor has the corresponding rotated geometry, with small inherited differences in the adjacent wall lips.

The original side and end lips sit slightly above or below the nominal floor top in the source model. Accordingly, these are projected overlap measurements, not claims of exact physical contact or stiffness. The floor's four side tabs, nine fixing axes, and their surrounding mounting material provide the retained attachment geometry; the opened corner contacts should not be described as fully preserved.

The proposal script only constructs a candidate in memory. It exports no model and changes no CAD file. The final exported-floor audit is `verify_floor_exports.py`, with results in `independent-floor-export-review.json` and `.md`.
