"""Read-only mechanical analysis of the proposed 12/16 mm floor chamfers.

The virtual candidate exists only in memory; this does not export or edit CAD.
"""
from pathlib import Path
import json
import math
import cadquery as cq
import numpy as np
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib

ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'10box-v2-r5/source-r4/step'
OUT=Path(__file__).resolve().parent

def bounds(s):
    q=Bnd_Box();BRepBndLib.AddOptimal_s(s.wrapped,q,False,False)
    return np.array(q.Get(),dtype=float)

def load(pid):return cq.importers.importStep(str(BASE/(pid+'.step'))).val()

def top(s):
    z=bounds(s)[5]
    return max([f for f in s.Faces() if f.normalAt().z>.9999 and abs(f.Center().z-z)<1e-6],key=lambda f:f.Area())

def box(b):return cq.Solid.makeBox(*(np.array(b[3:])-np.array(b[:3])),cq.Vector(*b[:3]))

def footprint_contact(s,f):
    # Project each planar horizontal retaining lip onto the actual floor top.
    return top(s).intersect(f.translate((0,0,bounds(s)[5]-f.Center().z))).Area()

def main():
    old=load('body-bottom-back')
    A=224.04716;B=220.04716;yc=72.49716
    pts=[((p-q)/2,(p+q)/2+yc) for p,q in [(A,B),(-A,B),(-A,-B),(A,-B)]]
    clip=cq.Workplane('XY').workplane(offset=-1).polyline(pts).close().extrude(7).val()
    candidate=old.intersect(clip).clean()
    rings=top(old).innerWires()
    rows=[]
    for w in rings:
        b=bounds(w);c=(b[:3]+b[3:])/2;verts=np.array([v.toTuple() for v in w.Vertices()])
        p=verts[:,0]+verts[:,1]-yc;q=-verts[:,0]+verts[:,1]-yc
        chamfer_web=min(A-p.max(),A+p.min(),B-q.max(),B+q.min())/math.sqrt(2)
        cp=c[0]+c[1]-yc;cqv=-c[0]+c[1]-yc
        nominal_clearance=min(A-abs(cp),B-abs(cqv))/math.sqrt(2)-5
        ring=cq.Solid.makeCylinder(5,.01,cq.Vector(c[0],c[1],4.99)).cut(cq.Solid.makeCylinder(2.75,.01,cq.Vector(c[0],c[1],4.99)))
        before=old.intersect(ring).Volume()/.01;after=candidate.intersect(ring).Volume()/.01
        dx,dy=b[3]-b[0],b[4]-b[1]
        travel=(max(dx,dy)-min(dx,dy))/2
        whole_travel_clearance=nominal_clearance-travel/math.sqrt(2)
        rows.append({'slot_center_xy_mm':c[:2].tolist(),'slot_bounds_mm':b.tolist(),
                     'minimum_new_diagonal_edge_web_mm':float(chamfer_web),
                     'nominal_OD10_washer_diagonal_clearance_mm':float(nominal_clearance),
                     'OD10_washer_full_nominal_slot_travel_diagonal_clearance_mm':float(whole_travel_clearance),
                     'original_washer_contact_mm2':before,'candidate_washer_contact_mm2':after})
    tabs=[]
    for sign in [-1,1]:
        for y0,y1 in [(45,65),(85,105)]:
            x0,x1=sorted([sign*163.55,sign*168.4])
            region=box([x0,y0,0,x1,y1,5])
            before=old.intersect(region);after=candidate.intersect(region)
            tabs.append({'sign':sign,'y_span_mm':[y0,y1],
                         'original_volume_mm3':before.Volume(),'candidate_volume_mm3':after.Volume(),
                         'removed_mm3':before.cut(after).Volume()})
    contact=[]
    for pid in ['body-left','body-right','body-back']:
        side=load(pid)
        for f in side.Faces():
            n=f.normalAt();b=bounds(f)
            if n.z<-.999999 and 4.9<f.Center().z<5.1 and f.Area()>5 and b[1]>=-1e-5:
                before=footprint_contact(old,f);after=footprint_contact(candidate,f)
                contact.append({'part':pid,'lip_bounds_mm':b.tolist(),'floor_to_lip_vertical_gap_mm':float(b[2]-5),
                                'original_projected_overlap_mm2':before,'candidate_projected_overlap_mm2':after,
                                'projected_overlap_lost_mm2':before-after})
    removed=old.cut(candidate)
    corners=[]
    for s in removed.Solids():
        b=bounds(s)
        corners.append({'bounds_mm':b.tolist(),'removed_volume_mm3':s.Volume(),
                        'opening_area_mm2':s.Volume()/5,'edge_leg_mm':float(max(b[3]-b[0],b[4]-b[1]))})
    rotated=candidate.translate((0,-yc,0)).rotate((0,0,0),(0,0,1),-45)
    rb=bounds(rotated)
    report={'candidate':'Four through-thickness corner chamfers, rear/common coordinates: |X+(Y-72.49716)| <=224.04716 and |-X+(Y-72.49716)| <=220.04716.',
            'scope':'Mechanical proposal only. No CAD files edited and no printer reach/slicing claim.',
            'valid':candidate.isValid(),'solid_count':len(candidate.Solids()),
            'original_volume_mm3':old.Volume(),'candidate_volume_mm3':candidate.Volume(),
            'removed_volume_mm3':removed.Volume(),'removed_projected_area_mm2':removed.Volume()/5,
            'removed_area_fraction':removed.Volume()/old.Volume(),
            'slot_count':len(top(candidate).innerWires()),'slots':rows,'tabs':tabs,'corners':corners,
            'corner_lip_projected_overlaps':contact,
            'yaw_minus45_xy_geometry_extent_mm':(rb[3:5]-rb[:2]).tolist()}
    (OUT/'floor-corner-proposal-review.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'valid':report['valid'],'solids':report['solid_count'],'slots':report['slot_count'],
                      'removed_mm3':report['removed_volume_mm3'],'min_new_diagonal_web_mm':min(x['minimum_new_diagonal_edge_web_mm'] for x in rows),
                      'min_nominal_washer_clearance_mm':min(x['nominal_OD10_washer_diagonal_clearance_mm'] for x in rows),
                      'min_travel_washer_clearance_mm':min(x['OD10_washer_full_nominal_slot_travel_diagonal_clearance_mm'] for x in rows),
                      'tabs_removed_mm3':sum(x['removed_mm3'] for x in tabs),'contact':contact,'rotated_xy_mm':report['yaw_minus45_xy_geometry_extent_mm']},indent=2))

if __name__=='__main__':main()
