"""R5 floor corner-clipping proposal and exact flat H2D envelope analysis.

Uses the existing floor's actual projected convex hull. No CAD files are edited.
"""
from pathlib import Path
import json,math,hashlib
import numpy as np
from scipy.spatial import ConvexHull
import cadquery as cq

WORK=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
DEPTH=144.99432;CENTER=np.array([0.,DEPTH/2]);A=224.04716;B=220.04716

def clip(poly,normal,limit):
    out=[];normal=np.array(normal,float)
    for i,a in enumerate(poly):
        b=poly[(i+1)%len(poly)];da=float(np.dot(normal,a)-limit);db=float(np.dot(normal,b)-limit)
        if da<=1e-9:out.append(a)
        if (da<=0)!=(db<=0):out.append(a+(b-a)*(da/(da-db)))
    return np.array(out)
def area(p):return abs(float(sum(np.cross(a,b) for a,b in zip(p,np.roll(p,-1,axis=0)))))/2 if len(p)>2 else 0.
def point_segment(p,a,b):
    d=b-a;t=np.clip(np.dot(p-a,d)/np.dot(d,d),0.,1.);return float(np.linalg.norm(p-(a+t*d)))
def polygon_distance(a,b):
    return min([point_segment(p,q,r) for p in a for q,r in zip(b,np.roll(b,-1,axis=0))]+[point_segment(p,q,r) for p in b for q,r in zip(a,np.roll(a,-1,axis=0))])

def main():
    path=WORK/'10box-v2-r4/step/body-bottom-back.step';shape=cq.importers.importStep(str(path)).val();vertices,_=shape.tessellate(.06,.2)
    points=np.array([p.toTuple() for p in vertices])[:,:2];poly=points[ConvexHull(points).vertices]-CENTER
    for n,limit in [([1,1],A),([-1,-1],A),([-1,1],B),([1,-1],B)]:poly=clip(poly,n,limit)
    c=math.sqrt(.5);rotation=np.array([[c,c],[-c,c]]);posed=poly@rotation.T+np.array([162.5,160.])
    lo,hi=posed.min(0),posed.max(0);size=hi-lo
    wipe=np.array([[145.,310.],[256.,310.],[256.,326.],[145.,326.]])
    intersect=posed.copy()
    for n,limit in [([-1,0],-145),([1,0],256),([0,-1],-310),([0,1],326)]:
        if len(intersect):intersect=clip(intersect,n,limit)
    min_edge=[lo[0],325-hi[0],lo[1],320-hi[1]]
    assert min(min_edge)>4 and area(intersect)<1e-8
    rear_strip=clip(posed,[0,-1],-310)
    result={'scope':'Actual source-floor hull clipped by the proposed diagonal halfplanes, then rigidly positioned. Conservative hull test clears the rear wipe rectangle without relying on an overlapping bounding rectangle.','source_step':path.relative_to(WORK).as_posix(),'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'local_center_xy_mm':CENTER.tolist(),'corner_legs_mm':{'NE':12,'SW':12,'NW':16,'SE':16},'keep_halfplanes_local_xy':[{'normal':[1,1],'max':A},{'normal':[-1,-1],'max':A},{'normal':[-1,1],'max':B},{'normal':[1,-1],'max':B}],'yaw_degrees':-45,'bed_center_xy_mm':[162.5,160.],'expected_footprint_xy_mm':size.tolist(),'bed_bounds_xy_mm':[lo.tolist(),hi.tolist()],'left_nozzle_area_xy_mm':[0,0,325,320],'minimum_nozzle_edge_margins_mm':{'left':min_edge[0],'right':min_edge[1],'front':min_edge[2],'rear':min_edge[3]},'wipe_exclusion_xy_mm':[145,310,256,326],'wipe_overlap_area_mm2':area(intersect),'conservative_hull_to_wipe_clearance_mm':polygon_distance(posed,wipe),'portion_above_y310_xrange_mm':[float(rear_strip[:,0].min()),float(rear_strip[:,0].max())],'posed_footprint_polygon_xy_mm':posed.tolist(),'removed_volume_mm3_nominal':2000,'brim':'none','supports':'none required for the flat5mm plate; actual slice remains pending'}
    OUT.mkdir(parents=True,exist_ok=True);(OUT/'fit-floor-clip-proposal.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['expected_footprint_xy_mm','minimum_nozzle_edge_margins_mm','wipe_overlap_area_mm2','conservative_hull_to_wipe_clearance_mm','portion_above_y310_xrange_mm']}))

if __name__=='__main__':main()
