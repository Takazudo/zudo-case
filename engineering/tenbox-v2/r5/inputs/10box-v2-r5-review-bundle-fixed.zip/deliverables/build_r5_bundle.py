"""Package the R5 clipped-floor CAD, configured flat H2D projects, and review."""
from pathlib import Path
import hashlib
import json
import os
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'deliverables'
OUT.mkdir(exist_ok=True)

def read(relative):
    return json.loads((ROOT / relative).read_text())

cad = read('10box-v2-r5/geometry-checks.json')
assert len(cad) == 82 and all(c['passed'] for c in cad)
floor = read('analysis/r5/independent-floor-export-review.json')
assert floor['failed'] == 0 and floor['passed'] == 27
printer = read('h2d-r5/h2d-project-report.json')
assert printer['project_count'] == 15
assert printer['stored_object_count'] == 22
assert printer['required_physical_part_count'] == 23
assert printer['global_settings_bytes_unchanged']
assert printer['flat_layouts_cover_all_required_parts']
assert printer['excluded_unresolved_flat_parts'] == []
assert printer['sliced'] is False
packages = read('h2d-r5/independent-package-review.json')
assert packages['all_included_projects_passed']
assert packages['flat_layouts_cover_all_required_parts']
assert packages['unresolved_flat_parts'] == []
assert packages['sliced'] is False
rebuild = read('analysis/r5/fit-reproducibility-check.json')
assert rebuild['passed'] and rebuild['project_count'] == 15
ui = read('preview-r5/qa/renderer-checks.json')
assert len(ui['checks']) == 36 and all(c['passed'] for c in ui['checks'])
import_repair = read('h2d-r5/import-repair-report.json')
assert import_repair['current_project_count'] == 15
assert import_repair['frozen_project_count'] == 14
assert import_repair['all29_original_dispatch_failed']
assert import_repair['all29_repaired_dispatch_passed']
compatibility = read('h2d-r5/studio-import-contract-review.json')
assert compatibility['archive_count'] == 29
assert compatibility['passed_count'] == 29 and compatibility['failed_count'] == 0
assert compatibility['all_source_dispatch_contracts_pass']
assert compatibility['studio_application_loaded'] is False

def copy_project_atomically(source, destination):
    body = source.read_bytes()
    descriptor, temporary_name = tempfile.mkstemp(prefix='.' + destination.name + '-', dir=OUT)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, 'wb') as stream:
            stream.write(body)
            stream.flush()
            os.fsync(stream.fileno())
        with zipfile.ZipFile(temporary) as archive:
            assert archive.testzip() is None
        assert temporary.read_bytes() == body
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)

floor_project = OUT / '10box-v2-r5-body-bottom-h2d-fixed.3mf'
roof_project = OUT / '10box-v2-r5-lid-h2d-fixed.3mf'
copy_project_atomically(ROOT / 'h2d-r5/projects/body-bottom-common.3mf', floor_project)
copy_project_atomically(ROOT / 'h2d-r5/projects/lid-top-single.3mf', roof_project)

files = {}

def add(path, name=None):
    files[name or path.relative_to(ROOT).as_posix()] = path.read_bytes()

notes = OUT / '10box-v2-r5-review-notes.md'
if not notes.exists():
    notes = ROOT / 'README.md'
preview = OUT / '10box-v2-r5-preview.html'
if not preview.exists():
    preview = ROOT / '10box-v2-r5-preview.html'
add(notes, 'README.md')
add(preview, '10box-v2-r5-preview.html')
add(Path(__file__))

for folder in ['10box-v2-r5', 'h2d-r5', 'analysis/r5']:
    for path in sorted((ROOT / folder).rglob('*')):
        if path.is_file() and path.suffix not in ['.log', '.pyc'] and '__pycache__' not in path.parts:
            add(path)

for name in ['viewer-app.js', 'viewer-built.js', 'tenbox-v2-template.html',
             'build_preview.py', 'build_print_scene.py', 'check_renderer.cjs', 'viewer-data.json']:
    add(ROOT / 'preview-r5' / name)
for name in ['renderer-checks.json', 'floor-fit.png', 'floor-top.png', 'underside.png',
             'original.png', 'lid-fit.png', 'lid-ledge.png', 'h2d.png',
             'narrow-floor-fit.png', 'narrow-underside.png']:
    add(ROOT / 'preview-r5/qa' / name)
for path in ['research/zudo-case/viewer-template.html', 'research/zzmod/rail-3u60-geometry.json']:
    add(ROOT / path)

files['MANIFEST.sha256'] = ''.join(
    f'{hashlib.sha256(body).hexdigest()}  {name}\n'
    for name, body in sorted(files.items())
).encode()
destination = OUT / '10box-v2-r5-review-bundle-fixed.zip'
descriptor, temporary_name = tempfile.mkstemp(prefix='.' + destination.name + '-', dir=OUT)
temporary = Path(temporary_name)
try:
    with os.fdopen(descriptor, 'wb') as stream:
        with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for name, body in files.items():
                archive.writestr(name, body)
        stream.flush()
        os.fsync(stream.fileno())
    with zipfile.ZipFile(temporary) as archive:
        assert archive.testzip() is None
        assert archive.read('h2d-r5/projects/body-bottom-common.3mf') == floor_project.read_bytes()
        assert archive.read('h2d-r5/projects/lid-top-single.3mf') == roof_project.read_bytes()
        assert len([n for n in archive.namelist() if n.startswith('h2d-r5/projects/') and n.endswith('.3mf')]) == 15
        for line in archive.read('MANIFEST.sha256').decode().splitlines():
            digest, name = line.split('  ', 1)
            assert hashlib.sha256(archive.read(name)).hexdigest() == digest
    os.replace(temporary, destination)
finally:
    temporary.unlink(missing_ok=True)

print(json.dumps({
    'bundle': str(destination),
    'bytes': destination.stat().st_size,
    'entries': len(files),
    'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
    'floor_project': str(floor_project),
    'roof_project': str(roof_project),
    'checks': {'cad': len(cad), 'independent_floor': floor['passed'],
               'preview': len(ui['checks']), 'projects': printer['project_count'],
               'required_physical_parts': printer['required_physical_part_count'],
               'import_contract_archives': compatibility['passed_count']},
    'sliced': False,
}))
