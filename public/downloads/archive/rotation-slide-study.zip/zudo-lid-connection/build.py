"""Build an offline standalone preview from the adjacent source files."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def build() -> Path:
    html = (ROOT / 'index.html').read_text(encoding='utf-8')
    html = html.replace('<link rel="stylesheet" href="styles.css">',
                        '<style>\n' + (ROOT / 'styles.css').read_text(encoding='utf-8') + '\n</style>')
    for name in ('three-bundle.js', 'model-data.js', 'app.js'):
        script = (ROOT / name).read_text(encoding='utf-8').replace('</script', '<\\/script')
        html = html.replace(f'<script src="{name}"></script>', '<script>\n' + script + '\n</script>')
    license_text = (ROOT / 'THREE-LICENSE.txt').read_text(encoding='utf-8')
    html = html.replace('<head>', '<!--\n' + license_text + '\n-->\n<head>', 1)
    output = ROOT / 'zudo-lid-connection-preview.html'
    output.write_text(html, encoding='utf-8')
    return output

if __name__ == '__main__':
    print(build())
