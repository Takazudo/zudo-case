/* ZUDO quick lid study. Reference meshes: R7. New mechanisms are illustrative, not manufacturing CAD. */
(async()=>{
'use strict';
const $=id=>document.getElementById(id), $$=q=>[...document.querySelectorAll(q)];
try{
 const bytes=Uint8Array.from(atob(window.ZUDO_MODEL_GZIP),c=>c.charCodeAt(0));
 if(!window.DecompressionStream) throw new Error('このブラウザは内蔵モデルの展開に対応していません。Chrome / Edge / Safariを更新してください。');
 const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
 const family=JSON.parse(await new Response(stream).text());
 run(family);
}catch(error){$('loading').hidden=true;$('error').hidden=false;$('errorText').textContent=error.message;console.error(error);}

function run(family){
 const T=window.THREE;
 const state={model:'7u40',mode:'turn',progress:0,ghost:false,colors:true,labels:true,detail:'front',view:'iso'};
 const modelNames={'7u40':'7U / 40HP','3u60':'3U / 60HP','7u60':'7U / 60HP'};
 const theme={metal:0x454b52,guards:0x262b31,rails:0x626b77,brackets:0x8e979f,spacers:0x30343c,fasteners:0xa3aab1,feet:0x20262e,lidMetal:0x454b52,lidFrame:0x30353b,lidGasket:0x252a30,lidHardware:0x8f9ca8,
  moving:0xe79851,lidReceiver:0x419acb,keeper:0xc6ad78,shaft:0xa2afb9,housing:0x4b5865,detailCase:0x9caeba};
 const objectMeshes=[], detailMeshes=[];
 let mainBuilt,detailBuilt,animation=null,resizeNeeded=true,frame=0,dirty=true;
 const main=makeWorld($('mainCanvas'),false), detail=makeWorld($('detailCanvas'),true);
 let focusGroup=new T.Group();main.scene.add(focusGroup);
 let detailGroup=new T.Group();detail.scene.add(detailGroup);
 const markerEls=[];
 const markerDefs=[];
 const raycaster=new T.Raycaster();const pointer=new T.Vector2();let down=null;
 main.renderer.domElement.addEventListener('pointerdown',e=>down={x:e.clientX,y:e.clientY});
 main.renderer.domElement.addEventListener('pointerup',e=>{if(!down||Math.hypot(e.clientX-down.x,e.clientY-down.y)>5)return;const r=main.renderer.domElement.getBoundingClientRect();pointer.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);raycaster.setFromCamera(pointer,main.camera);const hits=raycaster.intersectObjects(focusGroup.children,true);const hit=hits.find(h=>h.object.userData.action==='toggle');if(hit){if(state.progress<29.9)animateTo(30,650);else if(state.progress<=30.1)animateTo(0,650);}});

 function makeWorld(element,isDetail){
  const renderer=new T.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});
  renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,isDetail?1.75:1.6));renderer.setClearColor(isDetail?0xe6edf4:0xedf0f3,1);
  renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.2;
  renderer.domElement.setAttribute('aria-label',isDetail?'固定機構の拡大3D表示':'ケース全体の3D表示');
  element.appendChild(renderer.domElement);
  const scene=new T.Scene();const camera=new T.PerspectiveCamera(isDetail?34:35,1,.1,6000);camera.up.set(0,0,1);
  const controls=new window.OrbitControls(camera,renderer.domElement);controls.addEventListener('change',()=>{dirty=true;});controls.enableDamping=true;controls.dampingFactor=.09;controls.screenSpacePanning=true;controls.minDistance=isDetail?18:70;controls.maxDistance=isDetail?600:2300;
  const hemi=new T.HemisphereLight(0xffffff,0x748395,2.3);scene.add(hemi);
  const key=new T.DirectionalLight(0xffffff,2.5);key.position.set(140,-250,400);scene.add(key);
  const fill=new T.DirectionalLight(0xe2ecff,1.6);fill.position.set(-180,150,200);scene.add(fill);
  const room=new window.RoomEnvironment();const pmrem=new T.PMREMGenerator(renderer);scene.environment=pmrem.fromScene(room,.05).texture;room.dispose();pmrem.dispose();
  return {renderer,scene,camera,controls,element};
 }
 function mat(role,context=false,detailContext=false){
  const metal=['metal','lidMetal','brackets','fasteners','lidHardware','shaft'].includes(role);
  const m=new T.MeshStandardMaterial({color:theme[role]??0x777777,roughness:metal?.43:.83,metalness:metal?.55:.03,side:T.DoubleSide});
  m.userData={role,context,detailContext};return m;
 }
 function add(parent,g,pos,role,opts={}){
  const mesh=new T.Mesh(g,mat(role,!!opts.context,!!opts.detailContext));mesh.position.set(...pos);
  mesh.userData={role,action:opts.action,context:!!opts.context,detailContext:!!opts.detailContext,name:opts.name||role};
  parent.add(mesh);(opts.detail?detailMeshes:objectMeshes).push(mesh);
  if(opts.lines!==false){const eg=new T.EdgesGeometry(g,32),em=new T.LineBasicMaterial({color:0x374554,transparent:true,opacity:opts.detailContext?.22:.27});const edge=new T.LineSegments(eg,em);edge.userData.edge=true;mesh.add(edge);}
  return mesh;
 }
 function box(parent,w,d,h,pos,role,opts={}){return add(parent,new T.BoxGeometry(w,d,h),pos,role,opts);}
 function cyl(parent,r,h,pos,role,opts={}){return add(parent,new T.CylinderGeometry(r,r,h,36,1),pos,role,{...opts,lines:false});}
 function tube(parent,ro,ri,len,pos,role,opts={}){
  const s=new T.Shape();s.absarc(0,0,ro,0,Math.PI*2,false);const h=new T.Path();h.absarc(0,0,ri,0,Math.PI*2,true);s.holes.push(h);
  const g=new T.ExtrudeGeometry(s,{depth:len,bevelEnabled:false,curveSegments:32});g.rotateX(-Math.PI/2);return add(parent,g,pos,role,{...opts,lines:false});
 }
 function group(parent,pos=[0,0,0]){const g=new T.Group();g.position.set(...pos);parent.add(g);return g;}
 function reference(parent,p){
  const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(p.positions,3));if(p.indices)g.setIndex(p.indices);if(p.normals&&p.normals.length===p.positions.length)g.setAttribute('normal',new T.Float32BufferAttribute(p.normals,3));else g.computeVertexNormals();
  const context=['metal','guards','lidMetal','lidFrame','lidGasket'].includes(p.category);
  return add(parent,g,[0,0,0],p.category,{context,name:p.name,lines:p.positions.length<60000});
 }
 function circleHole(shape,x,z,r){const h=new T.Path();h.absarc(x,z,r,0,Math.PI*2,true);shape.holes.push(h);}
 function capsule(shape,x,z,length,width){
  const r=width/2,a=(length-width)/2,p=new T.Path();p.moveTo(x-a,z-r);p.lineTo(x+a,z-r);p.absarc(x+a,z,r,-Math.PI/2,Math.PI/2,false);p.lineTo(x-a,z+r);p.absarc(x-a,z,r,Math.PI/2,Math.PI*1.5,false);shape.holes.push(p);
 }
 function panel(parent,w,h,origin,holes,slots=[],opts={}){
  const s=new T.Shape();s.moveTo(-w/2,0);s.lineTo(w/2,0);s.lineTo(w/2,h);s.lineTo(-w/2,h);s.closePath();
  holes.forEach(v=>circleHole(s,v[0],v[1],v[2]));slots.forEach(v=>capsule(s,...v));
  // Shape XY maps to global XZ, depth maps toward -Y. Start at the inner surface.
  const g=new T.ExtrudeGeometry(s,{depth:1.5,bevelEnabled:false,curveSegments:16});g.rotateX(Math.PI/2);
  return add(parent,g,origin,opts.detail?'detailCase':'metal',{...opts,context:true});
 }
 function movingReceiver(parent,x,F,isDetail=false){
  const g=group(parent,[x,F,0]),o={detail:isDetail,name:'蓋側の受け'};
  box(g,13,1.5,18.2,[10.5,7.05,85.1],'lidReceiver',o); // spine: z76..94.2
  box(g,13,3.9,2,[10.5,5.75,77],'lidReceiver',o);      // shelf top z78; retained by cam above
  box(g,13,8.25,1.5,[10.5,3.675,93.45],'lidReceiver',o);
  return g;
 }
 function frontMechanism(fixed,lid,x,F,isDetail=false){
  const root=group(fixed,[x,F,80.5]),o={detail:isDetail};
  let rotor=null,slider=null;
  movingReceiver(lid,x,F,isDetail);
  if(state.mode==='turn'){
   tube(root,4.4,1.7,1.4,[0,1.65,0],'housing',o);
   tube(root,8.1,2.0,.7,[0,-.7,0],'housing',o);
   rotor=group(root);
   cyl(rotor,1.5,7.4,[0,1.3,0],'shaft',o);
   cyl(rotor,6.9,2.4,[0,-2.2,0],'moving',{...o,action:'toggle',name:'90°つまみ'});
   box(rotor,10.8,1.3,2.5,[0,-3.6,0],'moving',{...o,action:'toggle',name:'90°つまみ'});
   box(rotor,11.5,1.4,4,[5.25,4.7,0],'moving',{...o,name:'回転する内側の爪'});
   // Small witness marks around the face, not a designed detent.
   box(root,1.1,.35,1.1,[0,-.85,9.6],'keeper',o);box(root,1.1,.35,1.1,[9.6,-.85,0],'keeper',o);
  }else{
   // Guide does not extend into the lid receiver's upward extraction path (x >= 4).
   box(root,20,1.1,10,[-8,2.3,0],'housing',o);
   box(root,20,3.0,1.2,[-8,4.25,3.3],'housing',o);
   box(root,20,3.0,1.2,[-8,4.25,-3.3],'housing',o);
   box(root,1.4,3.0,6,[-18,4.25,0],'housing',o);
   box(root,25,1,1.1,[-11,-.5,5.0],'housing',o);box(root,25,1,1.1,[-11,-.5,-5.0],'housing',o);
   slider=group(root);
   box(slider,19,1.4,4,[1.5,4.7,0],'moving',{...o,name:'横に動くボルト'});
   cyl(slider,1.5,6.3,[-6,1.3,0],'shaft',o);
   box(slider,9,3.0,7.6,[-6,-2.3,0],'moving',{...o,action:'toggle',name:'スライドつまみ'});
   for(let i=-1;i<=1;i++)box(slider,.7,.6,5.4,[-6+i*2.2,-4,0],'keeper',{...o,action:'toggle'});
  }
  return {rotor,slider};
 }
 function rearMechanism(fixed,lid,x,B,isDetail=false){
  const g=group(fixed,[x,B,0]),h=group(lid,[x,B,0]),o={detail:isDetail};
  // Case-side keeper; hook slips toward the front 2mm before lifting.
  box(g,20,1.4,16,[0,-2.2,80.5],'keeper',o);
  box(g,20,2.3,2,[0,-2.65,79.6],'keeper',o);
  cyl(g,1.5,4.4,[0,-.9,84.8],'shaft',o);
  cyl(g,3.3,1.1,[0,.55,84.8],'shaft',o);
  box(h,14,1.5,18.2,[0,-4.95,85.1],'lidReceiver',o);
  box(h,14,2.8,2,[0,-4.3,77.0],'lidReceiver',o);
  box(h,14,6,1.5,[0,-2.7,93.45],'lidReceiver',o);
 }
 function clear(parent,list){
  parent.traverse(obj=>{if(obj.isMesh||obj.isLineSegments){obj.geometry?.dispose();if(Array.isArray(obj.material))obj.material.forEach(m=>m.dispose());else obj.material?.dispose();}});
  parent.clear();list.length=0;
 }
 function rebuildMain(){
  clear(focusGroup,objectMeshes);
  const m=family[state.model],W=m.meta.metalEnvelopeMm[0],D=m.meta.metalEnvelopeMm[1];
  const base=group(focusGroup),lidShell=group(focusGroup),fixed=group(focusGroup),lidMech=group(focusGroup);
  for(const p of m.body) reference(base,p);
  for(const p of m.lid) reference(lidShell,p);
  const latchX=(W+2.4)*.3;
  const holes=m.frontHoles.map(h=>[h[0],h[2]-1.5,2.75]);
  const frontHoles=[...holes],slots=[];
  for(const x of [-latchX,latchX]){
   if(state.mode==='turn') frontHoles.push([x,79,1.7]);
   else slots.push([x-11,79,13.4,3.4]);
  }
  panel(base,W-3,89.5,[0,-D/2+1.5,1.5],frontHoles,slots);
  const backHoles=[...holes,...[-latchX,latchX].map(x=>[x,84.8-1.5,1.7])];
  panel(base,W-3,89.5,[0,D/2,1.5],backHoles);
  const locks=[frontMechanism(fixed,lidMech,-latchX,-D/2),frontMechanism(fixed,lidMech,latchX,-D/2)];
  rearMechanism(fixed,lidMech,-latchX,D/2);rearMechanism(fixed,lidMech,latchX,D/2);
  const floor=new T.Mesh(new T.PlaneGeometry(2200,2200),new T.MeshStandardMaterial({color:0xe3e7ec,metalness:0,roughness:1}));floor.position.z=-3.15;focusGroup.add(floor);floor.userData.floor=true;
  const grid=new T.GridHelper(1000,50,0xc8d1da,0xd4dde5);grid.rotation.x=Math.PI/2;grid.position.z=-3.1;grid.material.transparent=true;grid.material.opacity=.22;focusGroup.add(grid);
  // Contact shadow is an illustrative radial texture, not a mechanical simulation.
  const cvs=document.createElement('canvas');cvs.width=cvs.height=128;const ctx=cvs.getContext('2d');const grad=ctx.createRadialGradient(64,64,15,64,64,64);grad.addColorStop(0,'rgba(35,52,70,0.22)');grad.addColorStop(1,'rgba(35,52,70,0)');ctx.fillStyle=grad;ctx.fillRect(0,0,128,128);
  const shadow=new T.Mesh(new T.PlaneGeometry(W*1.45,D*1.4),new T.MeshBasicMaterial({map:new T.CanvasTexture(cvs),transparent:true,depthWrite:false}));shadow.position.z=-3.0;focusGroup.add(shadow);
  mainBuilt={base,lidShell,fixed,lidMech,locks,W,D,latchX,floor,grid};
  buildMarkers();applyMotion();applyLook();setView(state.view,true);
 }
 function rebuildDetail(){
  clear(detailGroup,detailMeshes);
  const fixed=group(detailGroup),lid=group(detailGroup);let locks=[];
  if(state.detail==='front'){
   locks=[frontMechanism(fixed,lid,0,0,true)];
   const holes=state.mode==='turn'?[[0,80.5-69,1.7]]:[];
   const slots=state.mode==='slide'?[[-11,80.5-69,13.4,3.4]]:[];
   panel(fixed,55,22,[0,1.5,69],holes,slots,{detail:true,detailContext:true});
   box(lid,39,1.5,29.5,[4,-.45,107.45],'lidFrame',{detail:true,detailContext:true});
   box(lid,39,12,1.5,[4,4.8,122.95],'lidMetal',{detail:true,detailContext:true});
   box(fixed,55,3.4,1.2,[0,1.3,91.6],'guards',{detail:true,detailContext:true});
  }else{
   rearMechanism(fixed,lid,0,0,true);
   panel(fixed,44,22,[0,0,69],[[0,84.8-69,1.7]],[],{detail:true,detailContext:true});
   box(lid,35,1.5,29.5,[0,.45,107.45],'lidFrame',{detail:true,detailContext:true});
   box(lid,35,12,1.5,[0,-4.8,122.95],'lidMetal',{detail:true,detailContext:true});
   box(fixed,44,3.4,1.2,[0,-1.3,91.6],'guards',{detail:true,detailContext:true});
  }
  detailBuilt={fixed,lid,locks};
  detail.controls.target.set(state.detail==='front'?3:0,state.detail==='front'?3:-3,88);
  if(state.detail==='front')detail.camera.position.set(44,-51,108);else detail.camera.position.set(58,-6,95);detail.controls.update();
  applyMotion();applyLook();resizeNeeded=true;
 }
 function buildMarkers(){
  $('markers').innerHTML='';markerEls.length=0;markerDefs.length=0;
  const {D,latchX}=mainBuilt;
  const specs=[[-latchX,-D/2-4,87,'手前① 操作',false],[latchX,-D/2-4,87,'手前② 操作',false],[-latchX,D/2,94,'奥① 固定フック',true],[latchX,D/2,94,'奥② 固定フック',true]];
  for(const [x,y,z,label,rear] of specs){const e=document.createElement('div');e.className='marker'+(rear?' rear':'');e.textContent=label;$('markers').append(e);markerEls.push(e);markerDefs.push(new T.Vector3(x,y,z));}
 }
 function pose(){const p=state.progress;return {u:Math.min(p/30,1),dy:-2*Math.max(0,Math.min((p-30)/20,1)),dz:110*Math.max(0,Math.min((p-50)/50,1))};}
 function applyMotion(){
  dirty=true;
  const {u,dy,dz}=pose();
  if(mainBuilt){mainBuilt.lidShell.position.set(0,dy,dz);mainBuilt.lidMech.position.set(0,dy,dz);for(const l of mainBuilt.locks){if(l.rotor)l.rotor.rotation.y=-u*Math.PI/2;if(l.slider)l.slider.position.x=-10*u;}}
  if(detailBuilt){detailBuilt.lid.position.set(0,dy,dz);for(const l of detailBuilt.locks){if(l.rotor)l.rotor.rotation.y=-u*Math.PI/2;if(l.slider)l.slider.position.x=-10*u;}}
  syncUI();
 }
 function applyLook(){
  dirty=true;
  for(const mesh of [...objectMeshes,...detailMeshes]){
   const role=mesh.userData.role;let color=theme[role]??0x777777;
   if(!state.colors&&['moving','lidReceiver','keeper'].includes(role))color=role==='keeper'?0x727981:0x262d36;
   mesh.material.color.setHex(color);
   let opacity=1;
   if(mesh.userData.detailContext)opacity=role==='metal'||role==='detailCase'?.18:.1;
   else if(mesh.userData.context&&state.ghost)opacity=['metal','lidMetal'].includes(role)?.12:.22;
   mesh.material.opacity=opacity;mesh.material.transparent=opacity<1;mesh.material.depthWrite=opacity>=1;
   mesh.material.needsUpdate=true;
   for(const child of mesh.children)if(child.userData.edge){child.material.opacity=mesh.userData.detailContext?.16:opacity<1?.15:.27;}
  }
 }
 function syncUI(){
  const p=state.progress,{u,dy,dz}=pose();
  const prefix=state.mode==='turn'?'90°回転':'スライド';
  let title,desc,status,caption;
  if(p<.01){title='固定した状態';desc='手前２点の爪と、奥２点の固定フックで、蓋の抜けを止めます。';status='ロック中';}
  else if(p<30){title='1 / 手前２点を解除';desc=state.mode==='turn'?'つまみを90°回し、内側の爪を上へ逃がします。':'つまみを横に10mm動かし、青い受けからボルトを外します。';status='解除操作中';}
  else if(p<30.01){title='1 / 手前のロックを解除';desc='手前は解除済み。奥のフックはまだ掛かっているので、このまま上には抜けません。';status='手前２点を解除';}
  else if(p<50.01){title='2 / 蓋を手前へ2mmずらす';desc='奥のフックを本体の受けから外します。後ろへ手を回す必要はない構成です。';status=p>=50?'フックも解除':'フックを外す';}
  else {title='3 / 蓋を真上へ取り外す';desc='ロック部品は本体側に残り、蓋を完全に取り外せます。閉じるときは逆の順です。';status='蓋を取り外す';}
  $('phaseTitle').textContent=title;$('phaseDesc').textContent=desc;$('statusText').textContent=status;
  $('motionText').textContent=(state.mode==='turn'?Math.round(u*90)+'°':(u*10).toFixed(1)+' mm')+' / 蓋 '+dz.toFixed(0)+' mm';
  $('statusDot').style.background=p<.01?'#688457':'#d69a4c';
  $('modelLabel').textContent=modelNames[state.model]+' · '+prefix;
  $('progress').value=String(p);
  $('viewerCaption').textContent='奥２点は固定フック／手前２点だけ操作。前方は画面の「手前①・②」側です。';
  $('modeDescription').textContent=state.mode==='turn'?'回転軸と爪は本体側に残ります。横向きの爪が青い受けの上に重なり、蓋の上方への抜けを止める案です。':'横に動くボルトは本体側に残ります。青い受けの上へボルトを差し出し、蓋の上方への抜けを止める案です。';
  $('detailCaption').textContent=state.detail==='rear'?(p<=30?'青いフックが黄色の受けの下へ掛かります。':'手前へ2mmずらして掛かりを外し、上へ。'):(state.mode==='turn'?'橙の爪を90°回すと、青い受けを上へ抜けます。':'橙のボルトを横へ動かすと、青い受けを上へ抜けます。');
  const st=p<15?0:p<40?30:p<75?50:100;
  $$('[data-stage]').forEach(b=>b.classList.toggle('selected',Number(b.dataset.stage)===st));
  $$('[data-mode]').forEach(b=>b.classList.toggle('selected',b.dataset.mode===state.mode));
  $$('[data-detail]').forEach(b=>b.classList.toggle('selected',b.dataset.detail===state.detail));
  $$('[data-view]').forEach(b=>b.classList.toggle('selected',b.dataset.view===state.view));
  const dims=family[state.model].meta.metalEnvelopeMm;$('dimensions').textContent=dims.map(n=>Number(n).toFixed(1).replace('.0','')).join(' × ')+' mm｜本体アルミ外形 W × D × H';
  $('play').textContent=animation?'Ⅱ 一時停止':p>=99.9?'◀ 閉じる動きを再生':'▶ 開ける動きを再生';
 }
 function setView(view,instant=false){
  state.view=view;const {W,D}=mainBuilt;
  const target=new T.Vector3(0,0,60+pose().dz*.32),size=Math.max(W,D,220),aspect=main.element.clientWidth/Math.max(1,main.element.clientHeight);
  let distance=size/(2*Math.tan(main.camera.fov*Math.PI/360))*1.47;
  if(aspect<1)distance/=Math.max(.65,aspect);
  let dir={iso:[1,-1.27,.96],front:[0,-1,.25],back:[.5,1,.45],top:[.001,-.001,1]}[view]||[1,-1.27,.96];
  const offset=new T.Vector3(...dir).normalize().multiplyScalar(distance);main.camera.position.copy(target).add(offset);main.controls.target.copy(target);main.controls.update();syncUI();
 }
 function animateTo(to,duration=1300){animation={start:performance.now(),from:state.progress,to,duration};syncUI();}
 function resize(){
  for(const w of [main,detail]){const width=w.element.clientWidth,height=w.element.clientHeight;if(width&&height){w.renderer.setSize(width,height,false);w.camera.aspect=width/height;w.camera.updateProjectionMatrix();}}
  resizeNeeded=false;dirty=true;
 }
 function updateMarkers(){
  const r=main.element.getBoundingClientRect(),camera=main.camera;
  markerDefs.forEach((point,i)=>{const el=markerEls[i];el.style.display=state.labels?'block':'none';if(!state.labels)return;const p=point.clone().project(camera);if(p.z<0||p.z>1||Math.abs(p.x)>1.05||Math.abs(p.y)>1.05){el.style.display='none';return;}el.style.left=((p.x+1)/2*r.width)+'px';el.style.top=((-p.y+1)/2*r.height-7)+'px';});
 }
 function render(_rafTime){
  const now=performance.now();
  requestAnimationFrame(render);
  if(resizeNeeded)resize();
  if(animation){const t=Math.min((now-animation.start)/animation.duration,1),e=.5-.5*Math.cos(t*Math.PI);state.progress=animation.from+(animation.to-animation.from)*e;if(t>=1)animation=null;applyMotion();}
  main.controls.update();detail.controls.update();
  if(dirty){dirty=false;main.renderer.render(main.scene,main.camera);detail.renderer.render(detail.scene,detail.camera);updateMarkers();frame++;}
 }
 $('progress').addEventListener('input',e=>{animation=null;state.progress=Number(e.target.value);applyMotion();});
 $('play').onclick=()=>{if(animation){animation=null;syncUI();}else animateTo(state.progress>=99.9?0:100,3600);};
 $('reset').onclick=()=>animateTo(0,1300);
 $$('[data-stage]').forEach(b=>b.onclick=()=>animateTo(Number(b.dataset.stage),700));
 $$('[data-mode]').forEach(b=>b.onclick=()=>{animation=null;state.mode=b.dataset.mode;state.progress=0;rebuildMain();rebuildDetail();});
 $$('[data-detail]').forEach(b=>b.onclick=()=>{state.detail=b.dataset.detail;rebuildDetail();});
 $$('[data-view]').forEach(b=>b.onclick=()=>setView(b.dataset.view));
 $('model').onchange=e=>{animation=null;state.model=e.target.value;state.progress=0;rebuildMain();rebuildDetail();};
 $('ghost').onchange=e=>{state.ghost=e.target.checked;applyLook();};$('colors').onchange=e=>{state.colors=e.target.checked;applyLook();};$('labels').onchange=e=>{state.labels=e.target.checked;dirty=true;};
 $('saveImage').onclick=()=>{main.renderer.render(main.scene,main.camera);const a=document.createElement('a');a.href=main.renderer.domElement.toDataURL('image/png');a.download=`zudo-${state.model}-${state.mode}-lid-study.png`;a.click();};
 const ro=new ResizeObserver(()=>{resizeNeeded=true;});ro.observe(main.element);ro.observe(detail.element);
 window.addEventListener('resize',()=>resizeNeeded=true);
 rebuildMain();rebuildDetail();resize();setView('iso',true);$('loading').hidden=true;requestAnimationFrame(render);
 window.__lidStudy={state,main,detail,family,
  setProgress(p){animation=null;state.progress=p;applyMotion();},
  setMode(mode){animation=null;state.mode=mode;state.progress=0;rebuildMain();rebuildDetail();},
  setModel(model){animation=null;state.model=model;$('model').value=model;state.progress=0;rebuildMain();rebuildDetail();},
  setDetail(mode){state.detail=mode;rebuildDetail();},
  setLook(ghost,colors){state.ghost=ghost;state.colors=colors;$('ghost').checked=ghost;$('colors').checked=colors;applyLook();},
  setView,
  stats(){return{...state,pose:pose(),mainMeshes:objectMeshes.length,detailMeshes:detailMeshes.length,frame,positions:mainBuilt.locks.map(l=>({rotation:l.rotor?.rotation.y,slide:l.slider?.position.x})),lid:mainBuilt.lidMech.position.toArray()};}
 };
}
})();
